PARAGON ACES PHONE PWA

Upload the CONTENTS of this folder (index.html, manifest.webmanifest, sw.js, both PNG icons) to a static HTTPS host such as Netlify Drop or GitHub Pages. Do not upload only the HTML.

On iPhone: open the HTTPS website in Safari, tap Share, then Add to Home Screen (or Open as Web App where offered).
On Android: open the HTTPS website in Chrome, tap menu, then Install app or Add to Home screen.

Offline: core interface is cached after first successful online visit; external Google fonts and on-demand PDF/Excel libraries may need internet.

Data: app data may be stored on this device/browser. Installing on two phones does NOT synchronize data between them. Back up/export data before clearing site storage.
